#include<apue.h>
#include<stdio.h>

int main(void)
{
	printf("HelloWorld!\n");
	getchar();
	exit(0);
}
