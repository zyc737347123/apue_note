#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>
#include <shell.h>

int main(int argc, char ** argv)
{
	shell_init();
	shell_run();

	return 0;
}
