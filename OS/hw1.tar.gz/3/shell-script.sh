#!/bin/bash
echo Runing a shell script!
./helloworld-getchar
